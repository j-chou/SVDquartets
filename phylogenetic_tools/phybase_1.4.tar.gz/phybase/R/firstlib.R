#.First.lib <- function(lib,pkg)
#{
#   library.dynam("phybase",pkg,lib)
#   cat("tripleML 0.1-1 loaded\n")
#}
