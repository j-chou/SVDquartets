`plottree` <-
function(tree)
{
	plot.phylo(read.tree(text=tree))   
}
